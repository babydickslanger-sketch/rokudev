function Init()
    m.busySpinner = m.top.findNode("busySpinner")
    poster = m.busyspinner.poster
    poster.width = 150
    poster.height = 150
    poster.loadWidth = 150
    poster.loadHeight = 150
    poster.loadDisplayMode = "limitSize"
    ' bs:disable-next-line NO_OBSERVE_STRING_CALLBACK
    poster.observeField("loadStatus", "PositionSpinner")
    poster.uri = "pkg:/images/spinner.png"
    ' bs:disable-next-line NO_OBSERVE_STRING_CALLBACK
    m.top.observeField("visible", "OnVisibleChange")
end function

function PositionSpinner()
    if m.busyspinner.poster.loadStatus = "ready"
        centerx = (1280 - m.busyspinner.poster.width) / 2
        centery = (720 - m.busyspinner.poster.height) / 2
        m.busyspinner.translation = [
            centerx
            centery
        ]
    end if
end function

function OnVisibleChange()
    if m.busyspinner.visible
        m.busyspinner.control = "start"
    else
        m.busyspinner.control = "stop"
    end if
end function