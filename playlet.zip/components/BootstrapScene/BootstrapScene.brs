'import "LoadingMessages.bs"
'import "pkg:/source/Dialog.bs"
'import "pkg:/source/Logger.bs"
'import "pkg:/source/Manifest.bs"
'import "pkg:/source/Registry.bs"

function Init() as void
    m.scene = m.top.getScene()
    m.top.backgroundColor = "#242424FF"
    m.top.backgroundURI = ""
    m.loadingIndicator = m.top.findNode("LoadingIndicator")
    m.global.addFields({
        loadingIndicator: m.loadingIndicator
    })
    m.loadingIndicator.visible = true
    m.loadingIndicator.message = GetLoadingMessage()
    m.playletLibUrls = GetPlayletLibUrls()
    m.playletLibUrlIndex = 0
    LoadPlayletLib()
end function

function GetPlayletLibUrls() as object
    savedUrls = Registry_GetPlayletLibUrlsFromRegistry()
    if savedUrls <> invalid
        m.shouldClearRegistryOnLoadFail = true
        return savedUrls
    end if
    githubSquashFs = {
        type: "github-squashfs"
        link: Manifest_ReadValue("playlet_lib_squashfs_remote_url")
    }
    githubZip = {
        type: "github-zip"
        link: Manifest_ReadValue("playlet_lib_zip_remote_url")
    }
    embedded = {
        type: "embedded-zip"
        link: Manifest_ReadValue("playlet_lib_zip_embedded_url")
    }
    return [
        githubSquashFs
        githubZip
        embedded
    ]
end function

function LoadPlayletLib() as void
    if m.playletLibUrlIndex >= m.playletLibUrls.Count()
        m.loadingIndicator.visible = false
        if m.shouldClearRegistryOnLoadFail = true
            Registry_DeleteKey("playlet_lib_urls", "Playlet")
        end if
        ShowPlayletLibLoadErrorDialog()
        return
    end if
    RemoveComponentLibrary()
    uri = m.playletLibUrls[m.playletLibUrlIndex].link
    LoadComponentLibrary(uri)
end function

function OnLoadStatusChanged() as void
    libUrl = m.playletLibUrls[m.playletLibUrlIndex]
    if m.lib.loadStatus = "ready"
        RemoveComponentLibrary()
        Logger_Log(("Playlet lib loaded from " + bslib_toString(libUrl.link) + " in " + bslib_toString(m.timer.TotalMilliseconds()) + " ms"))
        m.timer = invalid
        m.scene.playletLibLoadedUrl = libUrl
        container = m.scene.findNode("MainSceneContainer")
        container.createChild("PlayletLib:MainScene")
        return
    end if
    if m.lib.loadStatus = "failed"
        Logger_Log(("Playlet lib failed to load from " + bslib_toString(libUrl.link) + " in " + bslib_toString(m.timer.TotalMilliseconds()) + " ms"))
        ' Try next url
        m.playletLibUrlIndex += 1
        LoadPlayletLib()
    end if
end function

function RemoveComponentLibrary() as void
    if m.lib = invalid
        return
    end if
    m.lib.unobserveField("loadStatus")
    m.scene.removeChild(m.lib)
    m.lib = invalid
end function

function LoadComponentLibrary(uri as string)
    m.timer = CreateObject("roTimespan")
    m.timer.mark()
    m.lib = m.scene.createChild("ComponentLibrary")
    ' bs:disable-next-line NO_OBSERVE_STRING_CALLBACK
    m.lib.observeField("loadStatus", "OnLoadStatusChanged")
    Logger_Log(("Loading Playlet lib from " + bslib_toString(uri)))
    m.lib.uri = uri
end function

function ShowPlayletLibLoadErrorDialog()
    message = [
        "Could not load Playlet component library from any of the following urls:"
    ]
    bulletText = []
    for each url in m.playletLibUrls
        bulletText.push("[" + url.type + "] " + url.link)
    end for
    bottomText = [
        "Please restart Playlet."
        "If the problem persist, contact Playlet authors."
    ]
    DialogShowError(message, bulletText, bottomText)
end function