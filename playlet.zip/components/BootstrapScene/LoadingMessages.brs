function GetLoadingMessage() as string
    messages = GetLoadingMessagesFromCache()
    if messages = invalid or messages.count() = 0
        messages = [
            "Now loading Playlet..."
            "One moment please..."
            "Downloading the internet..."
            "Unclogging the tubes..."
            "Warming up the flux capacitor..."
            "Loading, ehm, stuff..."
            "Restoring quantum entanglement..."
            "Searching for kitten videos..."
            "One Mississippi... two Mississippi..."
            "Checking the TV's extended warranty..."
            "Deleting system32..."
            "Updating: 3 hours 32 minutes remaining..."
            "Asking ChatGPT for humorous loading messages..."
            "Loading today's sponsor... Just kidding!"
            "Don't worry, this is normal..."
            "Don't forget to like and subscribe..."
            "Shoveling coal into the server..."
            "Counting down from infinity..."
            "Unfortunately, the internet is closed today..."
            "Unfortunately, we have no ads to show you..."
            "Looking for the remote..."
            "Finding that song that goes 'La la lala la'..."
            "Waiting for the spinny thing to finish..."
            "Oh I'm on TV... Hi mom!"
        ]
    end if
    index = GetRandom(0, messages.count() - 1)
    return messages[index]
end function

function GetLoadingMessagesFromCache() as object
    messagesFile = ReadAsciiFile("cachefs:/loading_messages_v1.json")
    if messagesFile = ""
        return invalid
    end if
    ' bs:disable-next-line NO_PARSE_JSON
    return ParseJson(messagesFile)
end function

function GetRandom(min as integer, max as integer) as integer
    dateTime = CreateObject("roDateTime")
    random = Rnd(max) + dateTime.GetMilliseconds()
    return min + (random mod (max - min + 1))
end function