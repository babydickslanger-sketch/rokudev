' Playlet (App to play videos from an Invidious server on Roku TVs)
' Copyright (C) 2025 Brahim Hadriche
' This program is free software: you can redistribute it and/or modify
' it under the terms of the GNU Affero General Public License as published by
' the Free Software Foundation, either version 3 of the License, or
' (at your option) any later version.
' This program is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
' GNU Affero General Public License for more details.

' You should have received a copy of the GNU Affero General Public License
' along with this program.  If not, see <https://www.gnu.org/licenses/>.
function Main(args as object) as void
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    m.global = screen.getGlobalNode()
    Logger_Init()
    Registry_ClearPlayletLibUrlsIfNeeded(args)
    Registry_ClearRegistryIfNeeded(args)
    Registry_ClearUnsupportedPlayletLibUrls()
    scene = screen.CreateScene("BootstrapScene")
    screen.show()
    AppManager_CaptureLastExitInfo(scene)
    SetScenePalette(scene)
    scene.ObserveField("exitChannel", port)
    scene.launchArgs = args
    if false
        ' These vars are needed to pass certification.
        ' The actual work is done in Playlet Lib
        ' bs:disable-next-line LINT1005
        _contentId = args.contentId
        ' bs:disable-next-line LINT1005
        _mediaType = args.mediaType
        ' Do not signal app launch complete here, we're doing it over at Playlet Lib
        ' This is needed to pass cetification
        scene.signalBeacon("AppLaunchComplete")
    end if
    input = CreateObject("roInput")
    input.setMessagePort(port)
    systemLog = CreateObject("roSystemLog")
    systemLog.SetMessagePort(port)
    scene.ObserveField("enableSystemLogType", port)
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSystemLogEvent"
            info = msg.GetInfo()
            info.DateTime = info.DateTime.ToISOString()
            scene.systemLogEvent = info
        else if msgType = "roSGScreenEvent"
            if msg.isScreenClosed()
                return
            end if
        else if msgType = "roSGNodeEvent"
            field = msg.getField()
            data = msg.getData()
            if field = "exitChannel" and data = true
                return
            end if
            if field = "enableSystemLogType"
                systemLog.EnableType(data)
            end if
        else if msgType = "roInputEvent"
            scene.inputArgs = msg.getInfo()
        end if
    end while
end function